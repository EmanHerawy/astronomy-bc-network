const Blockchain = require('./src/blockchain');
const chain = new Blockchain.Blockchain()
console.log(chain, 'chain');
chain.requestMessageOwnershipVerification("mzD4JjXv1LJBNoHZDwAQcwoCgfuvR4A1KW").then(msg=>console.log(msg,'message'))
submit().then();
async function submit() {
    const star1 = await chain.submitStar("mzD4JjXv1LJBNoHZDwAQcwoCgfuvR4A1KW", "mzD4JjXv1LJBNoHZDwAQcwoCgfuvR4A1KW:1587620090:starRegistry", "IEFbpe/X13OyIYqUMx91MUlBHQ81rgiJ+349X7LWmpqjffUCoJX8Vb7Cszd8EKbMAyNX6Ztlk+ft44jnYGN12dI=", {
        dec: "xxxx",
        Ro: "yyy",
        story: "zzz"
    })
    console.log(star1, 'star1');

    const star2 = await chain.submitStar("mzD4JjXv1LJBNoHZDwAQcwoCgfuvR4A1KW", "mzD4JjXv1LJBNoHZDwAQcwoCgfuvR4A1KW:1587620090:starRegistry", "IEFbpe/X13OyIYqUMx91MUlBHQ81rgiJ+349X7LWmpqjffUCoJX8Vb7Cszd8EKbMAyNX6Ztlk+ft44jnYGN12dI=", {
        dec: "xxxx",
        Ro: "yyy",
        story: "zzz"
    })
    console.log(star2, 'star2');

    // const star3 = await chain.submitStar("mzD4JjXv1LJBNoHZDwAQcwoCgfuvR4A1KW", "mzD4JjXv1LJBNoHZDwAQcwoCgfuvR4A1KW:1587620090:starRegistry", "IEFbpe/X13OyIYqUMx91MUlBHQ81rgiJ+349X7LWmpqjffUCoJX8Vb7Cszd8EKbMAyNX6Ztlk+ft44jnYGN12dI=", {
    //     dec: "xxxx",
    //     Ro: "yyy",
    //     story: "zzz"
    // })
    // console.log(star3, 'star3');
const filter=await chain.getStarsByWalletAddress("mzD4JjXv1LJBNoHZDwAQcwoCgfuvR4A1KW");
console.log(filter,'filter');

}